export default function Products() {
    return (
      <>
        <div className="main py-60">
          <div className="container-fluid">
            <h1>Product List:</h1>
            <h3>Product 1</h3>
            <h3>Product 2</h3>
            <h3>Product 3</h3>
            <h3>Product 4</h3>
            <h3>Product 5</h3>
          </div>
        </div>
      </>
    );
}