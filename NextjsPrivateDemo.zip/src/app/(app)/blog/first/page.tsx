export default function FirstBlog() {
  return (
    <>
      <div className="main py-60">
        <div className="container-fluid">
          <h1>First Blog Post</h1>
        </div>
      </div>
    </>
  );
}