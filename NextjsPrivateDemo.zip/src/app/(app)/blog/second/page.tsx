export default function SecondBlog() {
    return (
      <>
        <div className="main py-60">
          <div className="container-fluid">
            <h1>Second Blog Post</h1>
          </div>
        </div>
      </>
    );
}