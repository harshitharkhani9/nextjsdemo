export default function Blog() {
  return (
    <>
      <div className="main py-60">
        <div className="container-fluid">
          <h1>Blog page</h1>
        </div>
      </div>
    </>
  );
}
