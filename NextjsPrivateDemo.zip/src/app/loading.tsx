export default function Loading() {
    return (
        <>
            <div className="loaderwrapper">
                <div className="loader"></div>
            </div>
        </>
    );
  };