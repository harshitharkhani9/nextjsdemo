import React from 'react';

export const metadata = {
  title: 'Whiskwhet | Login',
  description: 'Author Login',
};
export default async function login() {
  return (
    <div className="main py-60">
      <div className="container-fluid">
        <h1>Login</h1>
      </div>
    </div>
  );         
}
